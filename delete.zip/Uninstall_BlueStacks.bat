@echo off
chcp 65001 >nul
title Полное удаление BlueStacks

:: Проверка прав администратора
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo [ОШИБКА] Запустите этот файл от имени администратора!
    pause
    exit /b
)

echo ====================================================
echo   ПОДГОТОВКА К УДАЛЕНИЮ BLUESTACKS
echo ====================================================
echo.

:: 1. Остановка процессов (если запущены)
echo [1/4] Остановка процессов BlueStacks...
taskkill /f /im HD-Player.exe >nul 2>&1
taskkill /f /im Bluestacks.exe >nul 2>&1
taskkill /f /im BstkSVC.exe >nul 2>&1
taskkill /f /im BlueStacksUninstaller.exe >nul 2>&1
taskkill /f /im BstkDrv_nxt.sys >nul 2>&1
echo Готово.

:: 2. Скачивание официальной утилиты очистки
echo.
echo [2/4] Скачивание официальной утилиты BlueStacks Cleaner...
:: Ссылка на официальную утилиту (версия для новых сборок)
set "URL=https://cdn3.bluestacks.com/bluestacks-cleaner/v1.09/BSTCleaner_native.exe"
set "DEST=%TEMP%\BSTCleaner.exe"

powershell -Command "Invoke-WebRequest -Uri '%URL%' -OutFile '%DEST%'" 
if not exist "%DEST%" (
    echo [ОШИБКА] Не удалось скачать утилиту. Проверьте интернет.
    pause
    exit /b
)

:: 3. Запуск утилиты
echo.
echo [3/4] Запуск утилиты очистки (следуйте инструкциям на экране)...
echo Если утилита не запустилась, найдите её вручную в папке %%TEMP%%: %DEST%
start /wait "" "%DEST%"

:: 4. Удаление основных папок (если утилита что-то пропустила)
echo.
echo [4/4] Удаление остаточных папок...
if exist "C:\Program Files\BlueStacks_nxt" rmdir /s /q "C:\Program Files\BlueStacks_nxt"
if exist "C:\Program Files\BlueStacks" rmdir /s /q "C:\Program Files\BlueStacks"
if exist "C:\Program Files (x86)\BlueStacks" rmdir /s /q "C:\Program Files (x86)\BlueStacks"
if exist "C:\ProgramData\BlueStacks" rmdir /s /q "C:\ProgramData\BlueStacks"
if exist "C:\ProgramData\BlueStacksSetup" rmdir /s /q "C:\ProgramData\BlueStacksSetup"
if exist "%LOCALAPPDATA%\BlueStacks" rmdir /s /q "%LOCALAPPDATA%\BlueStacks"

:: Очистка Temp
del /q /f /s "%TEMP%\*" >nul 2>&1
for /d %%p in ("%TEMP%\*") do rmdir /s /q "%%p" >nul 2>&1

echo.
echo ====================================================
echo   ГОТОВО.
echo   Рекомендуется перезагрузить компьютер.
echo ====================================================
pause